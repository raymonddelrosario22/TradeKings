-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 01, 2018 at 02:05 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `email`
--

-- --------------------------------------------------------

--
-- Table structure for table `crypto`
--

CREATE TABLE `crypto` (
  `email` varchar(9999) NOT NULL,
  `ticker` varchar(99) NOT NULL,
  `target` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `stock` varchar(99) NOT NULL,
  `stockPrice` int(11) NOT NULL,
  `stockPE` varchar(99) NOT NULL,
  `PE` int(11) NOT NULL,
  `Mark` int(11) NOT NULL DEFAULT '0',
  `Mark2` int(11) NOT NULL,
  `Mark3` int(11) NOT NULL,
  `type` varchar(999) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `crypto`
--

INSERT INTO `crypto` (`email`, `ticker`, `target`, `id`, `stock`, `stockPrice`, `stockPE`, `PE`, `Mark`, `Mark2`, `Mark3`, `type`) VALUES
('random1@gmail.com', 'NULL', 0, 28, 'googl', 10000, 'googl', 50, 1, 1, 0, 'buy'),
('random1@gmail.com', 'NULL', 0, 29, 'googl', 5, 'googl', 10, 1, 1, 0, 'sell'),
('random1@gmail.com', 'BTC', 10, 30, 'NULL', 0, 'NULL', 0, 0, 0, 1, 'sell'),
('random1@gmail.com', 'BTC', 1000000, 31, 'NULL', 0, 'NULL', 0, 0, 0, 1, 'buy'),
('random1@gmail.com', 'NULL', 0, 34, 'googl', 100000, 'googl', 10, 1, 0, 0, 'buy'),
('random1@gmail.com', 'NULL', 0, 35, 'googl', 1, 'googl', 500, 0, 1, 0, 'buy'),
('random1@gmail.com', 'NULL', 0, 36, 'googl', 20000, 'googl', 10, 0, 1, 0, 'sell'),
('random1@gmail.com', 'NULL', 0, 37, 'googl', 10000, 'NULL', 0, 1, 0, 0, 'buy');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `firstname` varchar(25) NOT NULL,
  `lastname` varchar(25) NOT NULL,
  `password` varchar(9999) NOT NULL,
  `email` varchar(9999) NOT NULL,
  `date` date NOT NULL,
  `profile_pic` varchar(9999) NOT NULL DEFAULT 'images/default_pic.png'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `password`, `email`, `date`, `profile_pic`) VALUES
(22, 'billnye', 'nye', '20eabe5d64b0e216796e834f52d61fd0b70332fc', 'random@gmail.com', '2018-03-30', 'images/default_pic.png'),
(23, 'billnye', 'bill', '20eabe5d64b0e216796e834f52d61fd0b70332fc', 'random@gmail.com', '2018-04-02', 'images/default_pic.png'),
(24, 'billnye', 'thesaladguy', '20eabe5d64b0e216796e834f52d61fd0b70332fc', 'random1@gmail.com', '2018-04-22', 'images/default_pic.png'),
(25, 'billnye', 'nye', '20eabe5d64b0e216796e834f52d61fd0b70332fc', 'randomer', '2018-04-25', 'images/default_pic.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `crypto`
--
ALTER TABLE `crypto`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `crypto`
--
ALTER TABLE `crypto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
