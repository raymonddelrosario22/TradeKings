
<?php
echo '<body style="background-color:pink">';
$apikey  = 'FC0H53AJLJN7ZI7H'; //API KEY
$interval = '1min';
$market = "EUR";
$symbol = 'BTC'; 

$function = 'DIGITAL_CURRENCY_INTRADAY';

$url = 'https://www.alphavantage.co/query?function='.$function.'&symbol='.$symbol.'&market='.$market.'&apikey='.$apikey;

$jsondata = file_get_contents($url);
$json = json_decode($jsondata,true);
$output = "<ul>";

$header = $json['Meta Data'];
echo "<strong>Stock Name: ", $header['3. Digital Currency Name'],"<br>";
echo "Last Refreshed: ", $header['7. Last Refreshed'],"<br>";
echo "Interval: ", $header['6. Interval'],"<br>";
echo "Type of Information:" .$function."</strong>";



foreach($json['Time Series (Digital Currency Intraday)'] as $stock){
$output .= "<li>1. Current Price: ".$stock['1b. price (USD)']."</li>"; 
break;
}
$output.="</ul>";
echo $output;
?>