
<?php


	
	
	
	$headers = "Welcome to Trade Kings";
	$message = "Dear ,/n/n/n	Welcome to Trade Kings, This is a test for the mail function";
	
	mail('SEND TO',$headers,$message,"From: HOST EMAIL"); 

	echo "Message was sent to INSERT EMAIL"

?>
