<?php
$connect=mysqli_connect("localhost","root","")or die("Couldn't Connect");

mysqli_select_db($connect,"forum")or die("Couldn't Connect");

?>
